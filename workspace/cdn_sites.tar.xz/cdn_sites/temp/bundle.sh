




cat "./base_packs/data_workarounds/JPath/transpiled/Simple/JPathData.js" >> "./tree_bundle.js"
cat "./base_packs/data_workarounds/JPath/transpiled/Simple/JPathImpl.js" >> "./tree_bundle.js"
cat "./base_packs/data_workarounds/JPath/transpiled/Simple/JPath.js" >> "./tree_bundle.js"

cat "./base_packs/EventEmitter/transpiled/Simple/EventEmitter.js" >> "./tree_bundle.js"
cat "./base_packs/EventEmitter/transpiled/Simple/ImprovedRenderEventEmitter.js" >> "./tree_bundle.js"

cat "./base_packs/text/parsers/TokensParser/transpiled/Simple/TokensParser.js" >> "./tree_bundle.js"
cat "./base_packs/text/renderers/TemplateRenderer/transpiled/Simple/TemplateRenderer.js" >> "./tree_bundle.js"

cat "./sites_tools/json_styling_tools/Tree/transpiled/Simple/typescript/ArrayOrObjectPackage.js" >> "./tree_bundle.js"
cat "./sites_tools/json_styling_tools/Tree/transpiled/Simple/typescript/TreeConstants.js" >> "./tree_bundle.js"
cat "./sites_tools/json_styling_tools/Tree/transpiled/Simple/typescript/TreeAdapter.js" >> "./tree_bundle.js"
cat "./sites_tools/json_styling_tools/Tree/transpiled/Simple/typescript/TreeAdapterModeEase.js" >> "./tree_bundle.js"
cat "./sites_tools/json_styling_tools/Tree/transpiled/Simple/typescript/TreeAdapterModeConf.js" >> "./tree_bundle.js"
cat "./sites_tools/json_styling_tools/Tree/transpiled/Simple/typescript/TreeConf.js" >> "./tree_bundle.js"
cat "./sites_tools/json_styling_tools/Tree/transpiled/Simple/typescript/Tree.js" >> "./tree_bundle.js"





