:: For options that take a <size> parameter,
:: suffix the number with "k" or "K" to indicate kilobytes,
:: "m" or "M" to indicate megabytes,
:: or "g" or "G" to indicate gigabytes.

:: -Xms set initial Java heap size
set START_MEMORY_HEAP_SIZE=64m

:: -Xmx set maximum Java heap size. If your jre runs out of memory, increase this parameter please
set MAX_MEMORY_HEAP_SIZE=4g


::--------------------------------------------------------------------------------
:: PARAMS FINISH
::================================================================================


::--------------------------------------------------------------------------------
:: DON'T EDIT HERE
::--------------------------------------------------------------------------------

echo off
cls
set start_mem=-Xms%START_MEMORY_HEAP_SIZE%
set max_mem=-Xmx%MAX_MEMORY_HEAP_SIZE%
cd ..
start java %start_mem% %max_mem% -jar "out/artifacts/jaisocx_http_jar/jaisocx-http.jar"
:: exit
